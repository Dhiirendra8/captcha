## Relevant articles:

- [Introduction to Jenetics Library](http://www.baeldung.com/jenetics)
- [Ant Colony Optimization](http://www.baeldung.com/java-ant-colony-optimization)
- [Design a Genetic Algorithm in Java](https://www.baeldung.com/java-genetic-algorithm)
- [The Traveling Salesman Problem in Java](https://www.baeldung.com/java-simulated-annealing-for-traveling-salesman)
