### Relevant Articles:
- [Intro to Apache BVal](http://www.baeldung.com/apache-bval)
