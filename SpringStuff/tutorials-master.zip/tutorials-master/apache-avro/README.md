### Relevant Articles:
- [Guide to Apache Avro](http://www.baeldung.com/java-apache-avro)
