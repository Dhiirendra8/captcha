### Relevant Articles:
- [Java Annotation Processing and Creating a Builder](http://www.baeldung.com/java-annotation-processing-builder)
